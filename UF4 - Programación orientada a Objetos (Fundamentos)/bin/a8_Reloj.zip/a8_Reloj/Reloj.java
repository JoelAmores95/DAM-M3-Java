package a8_Reloj;

public class Reloj {

	// Propiedades
	private int horas;
	private int minutos;
	private int segundos;

	// Constructores

	// Constructor vacío
	public Reloj() {

		this.horas = 00;
		this.minutos = 00;
		this.segundos = 00;

	}

	// Constructor con parámetros
	public Reloj(int horas, int minutos, int segundos) {

		// Horas
		if(horas < 24) {
			this.horas = horas;
		} else {
			System.out.println("Las horas deben estar entre 0 y 23.");
		}

		// Minutos
		if(minutos < 60) {
			this.minutos = minutos;
		} else {
			System.out.println("Los minutos deben estar entre 0 y 59");
		}

		// Segundos
		if(segundos < 60) {
			this.segundos = segundos;
		} else {
			System.out.println("Los segundos deben estar entre 0 y 59");
		}
	}


	// Setters y Getters
	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}

	public int getMinutos() {
		return minutos;
	}

	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}

	public int getSegundos() {
		return segundos;
	}

	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}

	// Método toString()
	@Override
	public String toString() {

		String strSegundos = "" + segundos;
		if(segundos < 10) {
			strSegundos = "0"+segundos;
		}

		String strMinutos= "" + minutos;
		if(minutos < 10) {
			strMinutos = "0"+minutos;
		}

		String strHoras= "" + horas;
		if(horas < 10) {
			strHoras = "0"+horas;
		}

		return strHoras + ":" + strMinutos + ":" + strSegundos;
	}

	// Método modificarHora()
	public boolean modificarHora(int horas, int minutos, int segundos) {

		// Horas
		if(horas < 0 || horas > 24) {
			return false;
		}
		// Minutos
		if(minutos < 0 || minutos > 60) {
			return false;
		}
		// Segundos
		if(segundos < 0 || segundos > 60) {
			return false;
		}

		// Todo OK
		setHoras(horas);
		setMinutos(minutos);
		setSegundos(segundos);
		return true;

	}

	// Funció per a poder sumar un segon a l’hora actual (a l’estil de l’exercici fet a la UF1).
	public void sumarSegundo() {

		if(getSegundos() == 59) {
			setSegundos(0);
			setMinutos(minutos + 1);
		} else {
			setSegundos(segundos + 1);
		}

		if(getMinutos() == 60) {
			setMinutos(0);
			setHoras(horas + 1);
		}
	}

	// Función para poder sumar un número determinado de segundos a la hora actual.
	public void sumarSegundos(int segundos) {

		// Tras sumar, hay mas de 59 segundos, sumo minutos
		if(getSegundos() + segundos > 59) {
			setMinutos(getMinutos() + ((getSegundos() + segundos) / 60));
			
			// Si hay mas de 59 minutos, sumo horas.
			if(getMinutos() > 59) {
				setHoras(getHoras() + (getMinutos() / 60));
				setMinutos(getMinutos() % 60);
			}
			setSegundos((getSegundos() + segundos) % 60);
			


		} else {

			setSegundos(segundos + getSegundos());
		}
	}

}
